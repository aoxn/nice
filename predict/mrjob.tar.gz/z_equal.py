#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'
from randssq import RandomNum

class Divide(RandomNum):

    def __init__(self):
        RandomNum.__init__(self)

    def search(self, num_arr):
        ret = []
        if len(num_arr) == 14:
            return [num_arr]
        x, y = self.do_partition(num_arr)
        tmp  = [ i for i in x + y if i]
        for i in range(0,len(tmp)-1):
            t_ret = self.search(self.re_combinate(tmp, i))
            for it in t_ret:
                if it not in ret: ret.append(it)
        return ret

    def re_combinate(self,arr, idx):
        ret = []
        for i,it in enumerate(arr):
            if i == idx:continue
            if i == idx + 1:continue
            ret += it
        return ret

    def do_partition(self,num_arr):
        num = len(num_arr)

        if num == 32:
            return [num_arr[i*4:(i+1)*4] for i in range(0,7)],[num_arr[4 * (8 - 1):num]]
        if num == 24:
            return [num_arr[i*3:(i+1)*3] for i in range(0,7)],[num_arr[3 * (8 - 1):num]]
        if num == 18:
            return [num_arr[i*2:(i+1)*2] for i in range(0,8)],[num_arr[2 * (9 - 1):num]]

    def devide_main(self):
        fil = self.over_continuous_in([],1779,6)
        print "FIL:",fil
        num = [i for i in range(1,34)]
        num.remove(fil[0])
        print num
        return self.search(num)

    def find(self,fd_set, idx):
        cnt =0
        ret = {}
        for i in range(idx,idx - 100, -1):
            red =  self.red_ball_row(i)

            for it in fd_set:
                inte = self.intersection(red,it)
                if len(inte) == 6:
                    cnt +=1
                    break
                else:
                    #pass
                    ret[str(red)] = 0

        ret = [ k for k,v in ret.items()]
        for im in ret:
            print im
        print cnt,len(ret)




if __name__ == "__main__":
    di = Divide()
    #n = [i for i in range(1,33)]
    #x,y = di.do_partition(n)
    #com =  [i for i in x+y if i]

    #re = di.re_combinate(com,0)
    #print com,re
    #m =[[1, 2, 3, 4, 5], [6, 7, 8, 9, 10], [11, 12, 13, 14, 15], [16, 17, 18, 19, 20], [21, 22, 23, 24, 25], [26, 27, 28, 29, 30], [31, 32, 33]]
    #print di.re_combinate(m,0)
    r = di.devide_main()
    print len(r),r
    di.find(r,1779)
    #print len(r),r

    #dv = Divide()
    #print dv.main()
