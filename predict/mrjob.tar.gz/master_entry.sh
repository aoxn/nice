!#/bin/bash
MASTER=124.228.238.14
echo "`date`: make ~/mrjob dir on ${MASTER}"
ssh -l xieyaoyao -p 32200 $MASTER 'mkdir -p mrjob'

echo "`date`: copy mrjob.tar.gz file to ${MASTER}"
scp -P 32200 /home/xieyaoyao/mrjob.tar.gz xieyaoyao@$MASTER:/home/xieyaoyao/

echo "`date`: untar mrjob.tar.gz and execute master.py"
ssh -l xieyaoyao -p 32200 $MASTER "cd /home/xieyaoyao/ && tar -xf mrjob.tar.gz -C mrjob/ && cd mrjob/ && python master.py master 'range(1,34)'"

echo "`date`: gather result.txt"
ssh -l xieyaoyao -p 32200 $MASTER 'cat /home/xieyaoyao/mrjob/final_result.txt'
