#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'
from randssq import RandomNum
import itertools as itto
import random,math,sys
import Queue
from ssq_filter import SsqFilter

class Divide(RandomNum):

    def __init__(self):
        RandomNum.__init__(self)



    def continue_search(self, idx,reds,first):
        END_LEN = 6
        pdt_map = {}
        progress= [0,0,0,0,0,0,0,0,0]
        pdt_que = Queue.Queue()
        filter  = SsqFilter(self,reds)
        for it in first:
            pdt_que.put(it)
        while not pdt_que.empty():
            level, nxt = pdt_que.get()
            if level>0 and filter.filted_begain(nxt):continue

            if progress[level] == 0:
                progress[level] =1
                self.log.debug("正在完成 %s%% progress[%s]..."%((level*20),progress))
            else:
                progress[level]+=1


            coms = self.re_combinate(nxt,level, reds)

            for com in coms:
                filter.filted_middle(com,level)
                if len(com)>END_LEN:
                    pdt_que.put((level+1,com))
                    continue
                com = sorted(com)
                num = pdt_map.get(str(com),0)

                if num > 0:
                    pdt_map[str(com)] = num + 1
                    continue

                if filter.filted_last(com): continue
                if filter.filted_finish(idx,com): continue
                pdt_map[str(com)] = num + 1


        return pdt_map


    def do_reduce(self,arr,r_cnt,step):
        size = len(arr)
        for i in range(0,int(math.ceil(float(size)/step)) - r_cnt/step + 1,1):
            f_part = arr[0:i*step]
            l_part = arr[(i+r_cnt/step)*step:size]
            tmp = f_part + l_part
            random.shuffle(tmp)
            yield tmp

        return

    def do_direct_combinate(self,arr):

        coms = itto.combinations(arr,6)
        for it in coms:
            yield it

        return

    def re_combinate(self,arr,level,reds):
        if level == 0:
            return self.do_reduce(arr,8,2)
        if level == 1:
            return self.do_reduce(arr,6,2)
        if level == 2:
            return self.do_reduce(arr,4,2)
        if level == 3:
            size = len(arr)
            if size == 15:
                return self.do_reduce(arr,3,1)
            return self.do_reduce(arr,4,2)
        if level == 4:
            #arr剩下12数，然后减两个
            return self.do_reduce(arr,2,2)
        if level == 5:
            #剩下10个数，直接组合
            return self.do_direct_combinate(arr)

        return []

    def find(self,fd_map, idx):
        #fd_map的键值被sort过，直接get
        red =  self.red_ball_row(idx+1)
        #s_red = sorted(red)
        r_6,r_5 = 0,0
        for k,v in fd_map.items():
            inte = self.intersection(red,eval(k))
            l = len(inte)
            if l == 6:
                r_6 +=v
            if l == 5:
                r_5 +=v
        return ("重合6个：",r_6,"重合5个：",r_5)


    def test_xxx(self,idx):
        #搜索第idx期的预测值
        T_NUM = 100
        cnt = 0
        r_map  = self.continue_search(idx,[self.red_ball_row(idx-1),
                                              self.red_ball_row(idx-2),
                                              self.red_ball_row(idx-3)],[(0,range(1,34))])
        self.log.debug(("TARGET RESULT COLLECTION SIZE: ",len(r_map)))

        for i in range(idx,idx - T_NUM, -1):
            self.log.debug("------------------------- 分割线 -------------------------------")
            result = self.find(r_map,i)
            self.log.debug("%s%s, %s%s"% result)
            if result[1] >= 1: cnt += 1
        self.log.debug("测试报告：%s 次测试中，共 %s 次命中6个。\n"%(T_NUM, cnt))

    def test_yyy(self,idx):
        #搜索第idx期的预测值
        T_NUM = 100
        cnt = 0
        for i in range(idx,idx - T_NUM, -1):
            self.log.debug("------------------------- 分割线 -------------------------------")

            r_map  = self.continue_search(i,[self.red_ball_row(i-1),
                                              self.red_ball_row(i-2),
                                              self.red_ball_row(i-3)],[(0,range(1,34))])
            self.log.debug(("TARGET RESULT COLLECTION SIZE: ",len(r_map)))

            result = self.find(r_map,i)

            self.log.debug("%s%s, %s%s"% result)

            if result[1] >= 1: cnt += 1
        self.log.debug("测试报告：%s 次测试中，共 %s 次命中6个。\n"%(T_NUM, cnt))

    def test_zzz(self,idx,first):
        self.log.debug("收到任务：长度 %s，",(len(first)))
        r_map  = self.continue_search(idx,[self.red_ball_row(idx-1),
                                              self.red_ball_row(idx-2),
                                              self.red_ball_row(idx-3)],first)

        self.log.debug("任务完成：ret %s"%(len(r_map)))
        return r_map




    def test_b(self):
        print self.continue_search(0,[])


    def test_c(self):
        coms = self.re_combinate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],4, [])
        for com in coms:
            print len(com),com


if __name__ == "__main__":
    di = Divide()
    #print di.ok()
    #print di.search(1779)
    #di.test_y(1779)
    #print di.divide(range(1,33),6)
    #di.do_partition(range(1,34))
    #di.test_z()
    #di.test_a(1)
    #di.test_b()
    #di.test_c()
    #di.test_d(1782)
    #di.test_xxx(1781)

    di.remove_file("result.txt")
    ret = di.test_zzz(1799,eval(sys.argv[1]))
    di.write2file(ret,"result.txt")
    #di.test_yyy(1781)
