#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'
from randssq import RandomNum
import itertools as itto
import random


class Divide(RandomNum):

    def __init__(self):
        RandomNum.__init__(self)

    def recursive(self, num_arr,reds):
        ret = []
        #if len(num_arr) == 24 or len(num_arr)==25:
        if len(num_arr) <=14:
            return [num_arr]
        tmp = self.do_partition(num_arr)
        #tmp  = [ i for i in x + y if i]
        for com in self.re_combinate(tmp,reds):
            t_ret = self.recursive(com, reds)
            for it in t_ret:
                if it not in ret: ret.append(it)
        return ret

    def re_combinate(self,arr,reds):
        record = []
        all = []
        for si in arr:
            all += si
        #ito = itto.combinations(arr,2)
        #for com in ito:
        #    for red in reds:
        #        fi = len(self.intersection(com[0],red))
        #        se = len(self.intersection(com[1],red))
        #        if fi > 0 and se > 0 and com not in record:
        #            record.append(com)
        #            tmp = com[0] + com[1]
        #            ret = self.difference(all,tmp)
        #            yield ret
        #if True: return
        size = len(arr)
        for i in range(0,size):
            if i == size-1:continue
            tmp = (arr[i],arr[i+1])
            if tmp not in record:
                record.append(tmp)
                rec = tmp[0] + tmp[1]
                ret = self.difference(all,rec)
                yield ret
        #print record

        return

    def do_partition(self,num_arr):
        num = len(num_arr)
        fi = num/8
        se = num%8
        par = [(i+1)*fi for i in range(0,8-se)]
        nxt = [(8-se)*fi+(fi+1)*(i+1) for i in range(0,se)]
        seq = par + nxt
        #print seq
        ret = []
        pre = 0
        for it in seq:
            ret += [num_arr[pre:it]]
            pre = it
        #print ret
        return ret
        #pre = 0
        #for i,it in enumerate(seq):

    def divide(self,arr,n):
        size = len(arr)
        fi,se = size/n,size%n
        return [arr[i*n:(i+1)*n] for i in range(0,fi)]+[arr[n*(fi):size]]

    #def do_partition(self,num_arr):
    #    num = len(num_arr)

    #    if num == 33:
    #        return [num_arr[i*4:(i+1)*4] for i in range(0,7)],[num_arr[4 * (8 - 1):num]]
    #    if num == 24:
    #        return [num_arr[i*3:(i+1)*3] for i in range(0,7)],[num_arr[3 * (8 - 1):num]]
    #    if num == 18:
    #        return [num_arr[i*2:(i+1)*2] for i in range(0,8)],[num_arr[2 * (9 - 1):num]]

    def search(self,idx):
        fil = self.over_continuous_in([],idx,6)
        num = range(1,34)
        fil=self.red_ball_row(idx)
        #fil = self.pick_up_ball()
        #print fil
        random.shuffle(fil)
        #print fil
        #fil=[1,1]
        #if len(fil)!=0:
        #    num.remove(fil[0])
        #else :
        #    fil = self.pick_up_ball()
        #    num.remove(fil[1])

        #red = self.red_ball_row(idx+1)
        #if fil[0] in red:
        #    print fil,red,"mmmmmmmmmmmmmmmmmmmmm"

        ret = self.recursive(num,[self.red_ball_row(idx),self.red_ball_row(idx),self.red_ball_row(idx)])
        self.log.debug(str((len(ret),ret)))
        return self.find(ret,idx)

    def find(self,fd_set, idx):

        red =  self.red_ball_row(idx+1)

        for it in fd_set:
            inte = self.intersection(red,it)
            if len(inte) == 6:
                return 1,red
        return 0,[]

    def test_xxx(self,num):
        cnt = 0
        for i in range(num,num - 1000, -1):
            c,tmp = self.search(i)
            self.log.debug(str((c,tmp)))
            if c == 1:
                cnt += 1
        print cnt

    def test_y(self,idx):
        ttl =0
        for i in range(idx,idx -100,-1):
            cnt = 0
            red = self.red_ball_row(i)
            div = self.divide(range(1,34),3)
            for i in range(0,len(div),2):
                if i == len(div)-2:break
                tmp = div[i]+div[i+1]
                print tmp

                l = len(self.intersection(red,tmp))
                if l==0:cnt+=1
            if cnt >=2:ttl+=1
            print red,cnt,ttl
        print ttl


if __name__ == "__main__":
    di = Divide()
    di.test_y(1779)
    print di.divide(range(1,33),6)
    #di.do_partition(range(1,34))
    #di.test_xxx(1781)
