!#/bin/bash
tar cf mrjob.tar.gz ./
scp -P 32200 /Users/spacex/work/dp/jasper-client/client/mrjob/mrjob.tar.gz mrjob.tar.gz xieyaoyao@58.215.46.21:/home/xieyaoyao/
ssh -l xieyaoyao -p 32200 58.215.46.21 'mkdir -p mrjob && tar xf mrjob.tar.gz -C mrjob/'
#ssh -l xieyaoyao -p 32200 58.215.46.21 'cd mrjob && bash master_entry.sh' 
