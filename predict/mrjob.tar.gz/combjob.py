#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'

import os
from mrjob.job import MRJob
import itertools as itto
from ssq import Ssq

class Prepare(Ssq):

    SIM_NUM = 4

    def __init__(self):
        Ssq.__init__(self)
        self.rebuild_input_file()

    def rebuild_input_file(self):
        total = len(self.data)-1
        if os.path.isfile("input.txt"):
            #os.remove("input.txt")
            return
        path = []
        self.log.debug("正在重新生成MRJOB输入文件。。。")
        with open("input.txt","w") as fd:
            self.search_union_recursive(total,4,4,path,fd)
            fd.flush()
        self.log.debug("MRJOB输入文件生成完毕")
        return

        #从第N期开始搜索交集大于M个的期数（C）集合
    def search_union_recursive(self, n, m, c, path,fd):
        path.append(n)
        if c==1:
            mid  = [self.red_ball_row(it) for it in path]
            fd.writelines(str(mid)+"\r\n")
            path.remove(n)
            return
        for i in range(n-1, n-600, -1):
            if len(self.intersection(self.red_ball_row(n),self.red_ball_row(i))) < 2: continue
            self.search_union_recursive(i, m, c-1, path,fd)
        path.remove(n)

class CombJob(MRJob):


    def mapper(self, key, value):
        value = eval(value)
        result= self.do_search_match(value)
        yield str(result)

    def reducer(self, key, values):
        result = []
        values = eval(values)
        for value in values:
            if not value[1]: result.append(value)
        yield result

    def do_search_match(self,value):
        candidate ,u, ret = value, [], []
        u = self.union(value)
        poss = itto.combinations(u,6)
        for p in poss:
            flag = True
            for can in candidate:
                #print p,can
                if len(self.intersection(p,can)) < 4:
                    flag = False
                    break
            if flag: ret.append(p)
        return value, ret

    def union(self, value):
        result = []
        for it in value:
            result = list(set(result).union(set(it)))
        return result


    def intersection(self, main, second):
        """
            两个集合的交集
        :param main:
        :param second:
        :return:
        """
        return list(set(main).intersection(set(second)))

if __name__ == "__main__":
    prepare = Prepare()

    CombJob.run()

