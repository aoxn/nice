!#/bin/bash
PID=$(ps -eaf|grep bash|grep mrjob.tar.gz|awk {'print $2'})
echo $PID 
kill -9 $PID


