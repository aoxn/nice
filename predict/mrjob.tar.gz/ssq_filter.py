#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'

import itertools as itto
import random

class SsqFilter:

    def __init__(self, context, reds):
        self.reds = reds
        self.connected_num = self.ob_connected_num(reds)
        self.context = context



    def ob_connected_num(self, reds):
        result = set()
        for red in reds:
            comb = itto.combinations(red,3)
            for com in comb:
                result.add(com)
        #print result

        return list(result)

    def random_remove(self,arr,ln=0.4):

        rnd = random.randint(1,20)
        if 1<= rnd <= 14:
            return False
        return True

    def remove_last_filter(self,pdt_red,level):
        #print "pdt,self.reds:%s,%s,%s"%(pdt_red,self.reds[0],self.reds)
        if level == 1 and len(self.context.intersection(pdt_red,self.reds[0])) == 0:
            return True

        return False

    def filted_begain(self,pdt_red,rnd=0.4):
        return self.random_remove(pdt_red)

    def filted_middle(self,pdt_red,level):

        return self.remove_last_filter(pdt_red,level)

    def filted_last(self, pdt_red):

        for fi in self.connected_num:
            if len(self.context.intersection(pdt_red,fi)) == len(fi):
                return True

        return False


    def filted_finish(self,idx, pdt_red):
        #返回True表示该数据被过滤掉了
        t_cnt,CNT,T_CNT = 0,4,4
        for tmp in range(idx-1, idx - 600,-1):
            if len(self.context.intersection(pdt_red,self.context.red_ball_row(tmp)))>=T_CNT:
                t_cnt += 1
            if t_cnt >= CNT: return False
        return True

if __name__=="__main__":
    red = [12,3,5,23,21,18]
    red = sorted([12,3,5,23,21,18])
    fi = SsqFilter([red])



