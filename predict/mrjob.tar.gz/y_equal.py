#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'
from randssq import RandomNum

class Divide(RandomNum):

    def __init__(self):
        RandomNum.__init__(self)

    def search(self, num_arr):
        ret = []
        if len(num_arr) == 6:
            return [num_arr]
        x, y = self.do_partition(num_arr)
        tmp  = [ i for i in x + y if i]
        for i in range(0,len(tmp)-1):
            t_ret = self.search(self.re_combinate(tmp, i))
            for it in t_ret:
                if it not in ret: ret.append(it)
        return ret

    def re_combinate(self,arr, idx):
        ret = []
        for i,it in enumerate(arr):
            if i == idx:continue
            if len(arr[0])!=3 and i == idx + 1:continue
            ret += it
        return ret

    def do_partition(self,num_arr):
        num = len(num_arr)
        x = num/6
        m = num%6
        if m != 0:
            return [num_arr[i*x:(i+1)*x] for i in range(0,6)],[num_arr[x * (7 - 1):num]]

        return [num_arr[i * (x - 1):(i + 1) * (x - 1)] for i in range(0,6)],[num_arr[(x - 1) * (7 - 1):num]]

    def devide_main(self):
        fil = self.over_continuous_in([],1779,6)
        print "FIL:",fil
        num = [i for i in range(1,34)]
        num.remove(fil[0])
        print num
        return self.search(num)

    def find(self,fd_set, idx):
        cnt =0
        for i in range(idx,idx - 100, -1):
            red =  self.red_ball_row(i)

            for it in fd_set:
                inte = self.intersection(red,it)
                if len(inte) == 6:
                    cnt +=1


        print cnt




if __name__ == "__main__":
    di = Divide()
    n = [i for i in range(1,14)]
    x,y = di.do_partition(n)
    com =  [i for i in x+y if i]

    re = di.re_combinate(com,0)
    #print com,re
    #m =[[1, 2, 3, 4, 5], [6, 7, 8, 9, 10], [11, 12, 13, 14, 15], [16, 17, 18, 19, 20], [21, 22, 23, 24, 25], [26, 27, 28, 29, 30], [31, 32, 33]]
    #print di.re_combinate(m,0)
    r = di.devide_main()
    print len(r)
    di.find(r,1779)
    #print len(r),r

    #dv = Divide()
    #print dv.main()
