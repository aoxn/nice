#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'
from randssq import RandomNum
import itertools as itto
import random,math,sys,commands,threading,os
import Queue
from ssq_filter import SsqFilter

class Task(threading.Thread):

    def __init__(self,host,half,log):
        threading.Thread.__init__(self)
        self.log = log
        self.host = host
        self.half = half

    def run(self):
        self.deploy()

    def deploy(self):

        action = "ssh -l xieyaoyao -p 32200 %s 'mkdir -p mrjob' && " \
                 "scp -P 32200 /home/xieyaoyao/mrjob.tar.gz xieyaoyao@%s:/home/xieyaoyao/ && " \
                 "ssh -l xieyaoyao -p 32200 %s \"cd /home/xieyaoyao/ && tar xf mrjob.tar.gz -C mrjob/ && cd mrjob/ && python master.py slave '%s'\" &&" \
                 "scp -P 32200 xieyaoyao@%s:/home/xieyaoyao/mrjob/result.txt tmp_result%s.txt"%(self.host,self.host,self.host,str(self.half),self.host,self.host)
        self.log.debug("ON ACTION: %s"%action)
        status,output = commands.getstatusoutput(action)
        #status,output = '',''
        if status!=0:
            raise Exception("we had problem execute [%s]"%(action))
            #print "execute error"
            pass
        return

class Divide(RandomNum):

    def __init__(self,tag):
        RandomNum.__init__(self)
        self.tag = tag
        self.jump = ""
        self.hosts = ["124.228.238.23","124.228.238.24"]


    def continue_search(self, idx,reds,first):
        END_LEN = 6
        pdt_map = {}
        progress= [0,0,0,0,0,0,0,0,0]
        pdt_que = Queue.Queue()
        filter  = SsqFilter(self,reds)
        print "FIRST: %s"%first
        for it in first:
            pdt_que.put(it)
        while not pdt_que.empty():
            level, nxt = pdt_que.get()
            if level>0 and filter.filted_begain(nxt):continue


            if progress[level] == 0:
                progress[level] =1
                self.log.debug("正在完成 %s%% progress[%s]..."%((level*20),progress))
            else:
                progress[level]+=1

            if tag=="master" and level ==1 :
                pdt_que.put((level,nxt))
                return self.do_master(pdt_que)

            #print nxt
            coms = self.re_combinate(nxt,level, reds)

            for com in coms:
                #print "com:%s"%com
                filter.filted_middle(com,level)
                if len(com)>END_LEN:
                    pdt_que.put((level+1,com))
                    continue
                com = sorted(com)
                num = pdt_map.get(str(com),0)

                if num > 0:
                    pdt_map[str(com)] = num + 1
                    continue

                if filter.filted_last(com): continue
                if filter.filted_finish(idx,com): continue
                pdt_map[str(com)] = num + 1



        return pdt_map

    def do_master(self,pdt_que):
        h_l = len(self.hosts)
        q_l = pdt_que.qsize()
        size= q_l/h_l
        print "host_len,que_len: %s,%s"%(h_l,q_l)
        tasks = []
        for i,host in enumerate(self.hosts):
            r = []
            if i == h_l:
                size = q_l - size*(i)
            for j in range(0,size):
                r.append(pdt_que.get())
            print "i,host,task: %s,%s,%s"%(i,host,r)
            tasks.append(Task(host,r,self.log))
        for task in tasks:
            task.start()
            self.log.debug("TASK: %s STARTED.ARGUMENT_LEN:%s, ARGUMENT:%s"%(task.host,len(task.half),task.half))
        for task in tasks:
            task.join()

        map = []

        for file in os.listdir(os.path.dirname(__file__)):
            if not file.startswith("tmp_result"):continue
            r_m = self.read_map(file)
            map = self.merge_map(map,r_m)

        return map

    def read_map(self,file):
        with open(file,"r") as fd:
            map = eval(fd.readall())
        return map

    def merge_map(self,r_map,l_map):

        for k,v in l_map.items():
            rk = r_map.get(k,0)
            r_map[k] = rk + 1

        return r_map


    def do_reduce(self,arr,r_cnt,step):
        size = len(arr)
        for i in range(0,int(math.ceil(float(size)/step)) - r_cnt/step + 1,1):
            f_part = arr[0:i*step]
            l_part = arr[(i+r_cnt/step)*step:size]
            tmp = f_part + l_part
            random.shuffle(tmp)
            yield tmp

        return

    def do_direct_combinate(self,arr):

        coms = itto.combinations(arr,6)
        for it in coms:
            yield it

        return

    def re_combinate(self,arr,level,reds):
        if level == 0:
            return self.do_reduce(arr,8,2)
        if level == 1:
            return self.do_reduce(arr,6,2)
        if level == 2:
            return self.do_reduce(arr,4,2)
        if level == 3:
            size = len(arr)
            if size == 15:
                return self.do_reduce(arr,3,1)
            return self.do_reduce(arr,4,2)
        if level == 4:
            #arr剩下12数，然后减两个
            return self.do_reduce(arr,2,2)
        if level == 5:
            #剩下10个数，直接组合
            return self.do_direct_combinate(arr)

        return []

    def find(self,fd_map, idx):
        #fd_map的键值被sort过，直接get
        red =  self.red_ball_row(idx+1)
        #s_red = sorted(red)
        r_6,r_5 = 0,0
        for k,v in fd_map.items():
            inte = self.intersection(red,eval(k))
            l = len(inte)
            if l == 6:
                r_6 +=v
            if l == 5:
                r_5 +=v
        return ("重合6个：",r_6,"重合5个：",r_5)




    def test_zzz(self,idx,first):
        self.log.debug("收到任务：长度 %s，",(1))
        r_map  = self.continue_search(idx,[self.red_ball_row(idx-1),
                                              self.red_ball_row(idx-2),
                                              self.red_ball_row(idx-3)],first)

        self.log.debug("任务完成：ret %s"%(len(r_map)))
        return r_map



if __name__ == "__main__":
    tag = sys.argv[1]
    di = Divide(tag)

    di.remove_file("result.txt")
    print sys.argv[1],eval(sys.argv[2])
    if tag =="master":
        ret = di.test_zzz(1779,[(0,eval(sys.argv[2]))])
    else:
        ret = di.test_zzz(1779,eval(sys.argv[2]))

    di.write2file(ret,"result.txt")

    print len(di.data)
    #di.test_yyy(1781)
