#!/usr/bin/env python2
# -*- coding: utf-8 -*-

__author__ = 'spacex'
from randssq import RandomNum
import itertools as itto
import random


class Divide(RandomNum):

    def __init__(self):
        RandomNum.__init__(self)
        self.record=[]

    def ok(self):
        return random.randint(0,5)

    def get_coms(self,num_arr):
        ret =[]
        coms = itto.combinations(num_arr,6)
        for it in coms:
            ret.append(it)
        return ret

    # 8 + 6 + 4  8+7 4     9 +6 4
    # 18     15    14      14
    #
    def do_reduce1(self,arr,i,n):
        '''
            在arr中过滤掉从第i个开始的n个数
        :param arr:
        :param i:
        :param n:
        :return:
        '''
        res = []
        for j,it in enumerate(arr):
            if j>=i and j<i+n:continue
            res += it
        return res
    def recursive(self, num_arr,c,reds):
        ret = []
        #if len(num_arr) == 26 or len(num_arr)==25:
        #print len(num_arr),"xxxx"
        if len(num_arr) <=14:
            return [num_arr]
            #return self.get_coms(num_arr)
        tmp = self.do_partition(num_arr)

        #tmp  = [ i for i in x + y if i]
        #print "par:",tmp
        coms=self.re_combinate(tmp,c,reds)
        for com in coms:
            #if self.ok()>2:continue
            t_ret = self.recursive(com,c+1, reds)
            for it in t_ret:
                if it not in ret: ret.append(it)
        l =len(ret)
        li=0

        #if c<=0:li = l/5+1

        #if c<=2:print c,li
        for i in range(0,li):
            r = random.randint(0,len(ret)-1)
            #print r
            ret.remove(ret[r])
        return ret

    def random_remove(self,arr,ln=0.6):
        li =int(ln*len(arr))
        li=0
        for i in range(0,li):
            r = random.randint(0,len(arr)-1)
            #print r
            arr.remove(arr[r])
        return arr

    def re_combinate(self,arr,c,reds):
        all = []
        for si in arr:
            all += si
        size = len(arr)
        #print "第c层：",c,size,len(all)
        for i in range(0,size):
            #print size,i
            tmp =[]
            if c==0:
                if i == size-3:break
                tmp = arr[i]+arr[i+1]+arr[i+2]+arr[i+3]
            elif c==1:
                if i == size-2:break
                tmp = arr[i]+arr[i+1]+arr[i+2]
            elif c==2:
                if i == size-1:break
                tmp = arr[i]+arr[i+1]
            elif c==3 and size==15:
                if i == size-1:break
                tmp = arr[i]+[arr[i+1][0]]
            elif c==3 and size==14:
                tmp = arr[i]
            else:
                tmp=arr[i]
            find =False
            #print len(self.record)
            #for re in self.record:
            #    l = len(self.intersection(re,tmp))
            #    if len(tmp)==l and len(re)==l:
            #        print "xxxxx:",find,re,tmp
            #        find = True
            #        break
            #lm =len(self.intersection(tmp,reds[0]))
            #if (c==0) and lm==0:continue
            #lm =len(self.intersection(tmp,reds[1]))
            #if (c==0) and lm==0:continue
            #lm =len(self.intersection(tmp,reds[2]))
            #if lm==0:continue
            if not find:
            #    self.record.append(tmp)
                ret = self.difference(all,tmp)
                #print ret
                if c>=0:random.shuffle(ret)
                #print tmp,ret
                yield ret
        #print record

        return


    def do_partition(self,arr):
        n = 2
        size = len(arr)
        fi,se = size/n,size%n
        #print fi,se
        if size==12:
            return [arr[i*1:(i+1)*1] for i in range(0,12)]
        if se == 0:
            return [arr[i*n:(i+1)*n] for i in range(0,fi)]
        return [arr[i*n:(i+1)*n] for i in range(0,fi)]+[arr[n*(fi):size]]

    def divide(self,arr,n):
        size = len(arr)
        fi,se = size/n,size%n
        #print fi,se
        return [arr[i*n:(i+1)*n] for i in range(0,fi)]+[arr[n*(fi):size]]

    #def do_partition(self,num_arr):
    #    num = len(num_arr)

    #    if num == 33:
    #        return [num_arr[i*4:(i+1)*4] for i in range(0,7)],[num_arr[4 * (8 - 1):num]]
    #    if num == 24:
    #        return [num_arr[i*3:(i+1)*3] for i in range(0,7)],[num_arr[3 * (8 - 1):num]]
    #    if num == 18:
    #        return [num_arr[i*2:(i+1)*2] for i in range(0,8)],[num_arr[2 * (9 - 1):num]]

    def search(self,idx):
        self.record=[]
        fil = self.over_continuous_in([],idx,6)
        num = range(1,34)
        fil=self.red_ball_row(idx)
        #fil = self.pick_up_ball()
        #print fil
        random.shuffle(fil)
        #print fil
        #fil=[1,1]
        #if len(fil)!=0:
        #    num.remove(fil[0])
        #else :
        #    fil = self.pick_up_ball()
        #    num.remove(fil[1])

        #red = self.red_ball_row(idx+1)
        #if fil[0] in red:
        #    print fil,red,"mmmmmmmmmmmmmmmmmmmmm"

        ret = self.recursive(num,0,[self.red_ball_row(idx),self.red_ball_row(idx-1),self.red_ball_row(idx-2)])
        ret = self.random_remove(ret)
        self.log.debug(str((len(ret),"jihe")))
        return self.find(ret,idx)

    def find(self,fd_set, idx):

        red =  self.red_ball_row(idx+1)
        r_6,r_5 = 0,0
        for it in fd_set:
            inte = self.intersection(red,it)
            l = len(inte)
            if l == 6:
                r_6 +=1
            if l == 5:
                r_5 +=1
        return ("r_6",r_6,"r_5",r_5)

    def test_xxx(self,num):
        cnt = 0
        for i in range(num,num - 100, -1):
            c = self.search(i)
            self.log.debug(str((c)))
            if c[1] >= 1:
                cnt += 1
        print cnt

    def test_y(self,idx):
        ttl =0
        for i in range(idx,idx -100,-1):
            cnt = 0
            red = self.red_ball_row(i)
            div = self.divide(range(1,34),3)
            for i in range(0,len(div),2):
                if i == len(div)-2:break
                tmp = div[i]+div[i+1]
                print tmp

                l = len(self.intersection(red,tmp))
                if l==0:cnt+=1
            if cnt >=2:ttl+=1
            print red,cnt,ttl
        print ttl

    def test_z(self):
        rec = []
        for i in range(0,20000):
            rec.append(self.pick_up_ball(6))
        red  = self.red_ball_row(1779)
        for it in rec:
            l = len(self.intersection(it,red))
            if l>=6:
                print it
        return

    def test_a(self,idx):
        a = [1,2,3,4,5,6,7,8,9,10,11,12]
        for i in range(0,10):
            random.shuffle(a)
            print a

if __name__ == "__main__":
    di = Divide()
    #print di.ok()
    #print di.search(1779)
    #di.test_y(1779)
    #print di.divide(range(1,33),6)
    #di.do_partition(range(1,34))
    #di.test_z()
    #di.test_a(1)
    di.test_xxx(1781)
