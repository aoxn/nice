!#/bin/bash
ips=(124.228.238.14 124.228.238.23 124.228.238.24)
for ip in ${ips[@]}
do
   echo $ip 
   ssh -l xieyaoyao -p 32200 $ip "cd /home/xieyaoyao/mrjob/ && bash kill_task.sh"

done
